<?php
require_once "dbConnector.php";
require_once "sessionConfig.php";
require_once "dbQueries.php";

if ($_SERVER["REQUEST_METHOD"] === "POST" AND isset($_POST['submitSignup'])) {

  $firstName = $_POST["firstName"];
  $lastName = $_POST["lastName"];
  $userName = $_POST["userName"];
  $email = $_POST["email"];
  $password = $_POST["password"];
  $mobileNumber = $_POST["mobileNumber"];

  // IMG support
  if(isset($_FILES["image"]) && $_FILES["image"]["error"] === UPLOAD_ERR_OK) {
  $imageName= $_FILES["image"]["name"];
  $imageTmpName = $_FILES["image"]["tmp_name"];
  $imageData = file_get_contents($imageTmpName);
  } else {
    $defaultImage = 'pics/default.png';
    $imageData = file_get_contents($defaultImage);
    $imageName = basename($defaultImage);
  }

  $errors = ErrorCheckSignup($connect, $firstName, $lastName, $userName, $email, $password, $mobileNumber);

  if ($errors) {
    $_SESSION['errorsSignup'] = $errors;
    header("Location: sign_up.php");
    mysqli_close($connect);
    die();
  }

  if (!insertData($connect, $firstName, $lastName, $userName, $email, $password, $mobileNumber, $imageName , $imageData)) {
    mysqli_close($connect);
      die("Query failed: " . mysqli_error($connect));
  }

  $_SESSION['successSignup'] = "Signup Success!";
  header("Location: login.php");
  mysqli_close($connect);
  die();

} else if ($_SERVER["REQUEST_METHOD"] === "POST" AND isset($_POST['submitEdit'])) {

  $firstName = $_POST["firstName"];
  $lastName = $_POST["lastName"];
  $userName = $_POST["userName"];
  $email = $_POST["email"];
  $password = $_POST["password"];
  $mobileNumber = $_POST["mobileNumber"];

  if(isset($_FILES["image"]) && $_FILES["image"]["error"] === UPLOAD_ERR_OK) {
    $imageName= $_FILES["image"]["name"];
    $imageTmpName = $_FILES["image"]["tmp_name"];
    $imageData = file_get_contents($imageTmpName);
  } else {
    $existingPictures = GetExistingPictures($connect, $_SESSION['accID']);
    $imageName = $existingPictures['profilePicName'];
    $imageData = $existingPictures['profilePic'];
  }

  UpdateData($connect, $firstName, $lastName, $userName, $email, $password, $mobileNumber, $imageName , $imageData, $_SESSION['accID']);


  $_SESSION['successEdit'] = "Edit Data Success!";
  header("Location: dashboard.php");
  mysqli_close($connect);
  die();

} else if ($_SERVER["REQUEST_METHOD"] === "POST" AND (isset($_POST['submitDelete'])) OR isset($_POST['submitExit'])) {

  if(isset($_POST['submitExit'])) {
    header("Location: index.php");
    mysqli_close($connect);
    die();
  }

  if(isset($_POST['submitDelete'])) {
    if(DeleteData($connect, $_SESSION['accID'])) {
        session_start();
        session_unset();
        session_destroy();
        header("Location: index.php");
        mysqli_close($connect);
        die();
    } else {
        // Error occurred while deleting the account
        echo "Failed to delete account.";
        exit;
    }
  }

} else {
  header("Location: sign_up.php");
  mysqli_close($connect);
  die();
}

function ErrorCheckSignup($connect, string $firstName, string $lastName, string $userName, string $email, string $password, string $mobileNumber) {
  $errors = [];

  if(empty($firstName) OR empty($lastName) OR empty($userName) OR empty($email) OR empty($password) OR empty($mobileNumber)) {
        $errors["emptyFields"] = "Fill out all the Fields!";
    } else {

      if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          $errors["invalidEmail"] = "Enter a valid Email!";
      }

      if(GetUsername($connect, $userName)) {
          $errors["takenUsername"] = "Username is already Taken!";
      }

      if(GetEmailSignup($connect, $email)) {
          $errors["takenEmail"] = "Email is already Taken!";
      }

      if(strlen($mobileNumber) < 11 OR strlen($mobileNumber) > 15) {
        $errors["invalidNumber"] = "Mobile Number must be 11-15 digits!";
      }

    }

  return $errors;
}