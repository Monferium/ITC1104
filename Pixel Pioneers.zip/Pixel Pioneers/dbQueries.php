<?php

function InsertData($connect, string $firstName, string $lastName, string $userName, string $email, string $password, string $mobileNumber, $imageName , $imageData) {
  $query = "INSERT INTO `accounts` (`firstName`, `lastName`, `userName`, `email`, `password`, `mobileNumber`, `profilePicName` , `profilePic`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "ssssssss", $firstName, $lastName, $userName,  $email, $password, $mobileNumber, $imageName , $imageData);
    $result = mysqli_stmt_execute($stmt);
    $isAffected = mysqli_stmt_affected_rows($stmt);
    mysqli_stmt_close($stmt);
  }
  return $result && $isAffected === 1;
  
}

function UpdateData($connect, string $firstName, string $lastName, string $userName, string $email, string $password, string $mobileNumber, $imageName , $imageData, $accID,) {
  $query = "UPDATE `accounts` SET `firstName` = ?, `lastName` = ?, `userName` = ?, `email` = ?, `password` = ?, `mobileNumber` = ?, `profilePicName` = ?, `profilePic` = ? WHERE `accID` = ?";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "ssssssssi", $firstName, $lastName, $userName,  $email, $password, $mobileNumber, $imageName , $imageData, $accID);
    $result = mysqli_stmt_execute($stmt);
    $isAffected = mysqli_stmt_affected_rows($stmt);
    mysqli_stmt_close($stmt);
  }
  return $result && $isAffected === 1;
}

function DeleteData($connect, $accID) {
  $query = "DELETE FROM `accounts` WHERE `accID` = ?";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "i", $accID);
    if (!mysqli_stmt_execute($stmt)) {
      echo "Error: " . mysqli_error($connect);
    }
    $isAffected = mysqli_stmt_affected_rows($stmt);
    mysqli_stmt_close($stmt);
  }
  return $isAffected === 1;
}

function GetUserAccount($connect, $accID) {
  $query = "SELECT `firstName`,`lastName`,`email`,`password`, `mobileNumber` FROM `accounts` WHERE `accID` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "i", $accID);
    mysqli_stmt_execute($stmt);
    $result = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
  }
  return $result;
}

function GetExistingPictures($connect, $accID) {
  $query = "SELECT `profilePicName`,`profilePic` FROM `accounts` WHERE `accID` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "i", $accID);
    mysqli_stmt_execute($stmt);
    $result = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
  }
  return $result;
}

function GetPictureUsername($connect, $accID) {
  $query = "SELECT `profilePic`, `userName` FROM `accounts` WHERE `accID` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "i", $accID);
    mysqli_stmt_execute($stmt);
    $result = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
  }
  return $result;
}

function GetProducts($connect, $prodID) {
  $query = "SELECT `name`, `price`, `image` FROM `products` WHERE `prodID` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "i", $prodID);
    mysqli_stmt_execute($stmt);
    $result = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
  }
  return $result;
}

function GetShoppingCart($connect, $accID) {
  $query = "SELECT `shopCID`, `prodID`, `name`, `description`, `cost`, `image` FROM `shoppingcart` WHERE `accID` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "i", $accID);
    mysqli_stmt_execute($stmt);
    $resultSet = mysqli_stmt_get_result($stmt);
    $result = array();
    while($row = mysqli_fetch_assoc($resultSet)) {
      $result[] = $row;
    }
    mysqli_stmt_close($stmt);
  }
  return $result;
}

function DeleteShoppingEntry($connect, $shopCID) {
  $query = "DELETE FROM `shoppingcart` WHERE `shopCID` = ?";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "i", $shopCID); // Corrected parameter binding
    mysqli_stmt_execute($stmt); // No need to check result
    $isAffected = mysqli_stmt_affected_rows($stmt);
    mysqli_stmt_close($stmt);
  }
  return $isAffected === 1;
}

function GetProductsSeller($connect, $accID) {
  $query = "SELECT `prodID`, `name`, `price`, `image`, `rating` FROM `products` WHERE `accID` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "i", $accID);
    mysqli_stmt_execute($stmt);
    $resultSet = mysqli_stmt_get_result($stmt);
    $result = array();
    while($row = mysqli_fetch_assoc($resultSet)) {
      $result[] = $row;
    }
    mysqli_stmt_close($stmt);
  }
  return $result;
}

function InsertShoppingCart($connect, $prodID, $accID, $name, $cost, $imageData) {
  $query = "INSERT INTO `shoppingcart` (`prodID`, `accID`, `name`, `cost`, `image`) VALUES (?, ?, ?, ?, ?)";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "iisds", $prodID, $accID, $name, $cost, $imageData);
    $result = mysqli_stmt_execute($stmt);
    $isAffected = mysqli_stmt_affected_rows($stmt);
    mysqli_stmt_close($stmt);
  }
  return $result && $isAffected === 1;
}

function GetRating($connect, $prodID) {
  $query = "SELECT `rating` FROM `reviews` WHERE `prodID` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "i", $prodID);
    mysqli_stmt_execute($stmt);
    $resultSet = mysqli_stmt_get_result($stmt);
    $result = array();
    while($row = mysqli_fetch_assoc($resultSet)) {
      $result[] = $row;
    }
    mysqli_stmt_close($stmt);
  }
  return $result;
}

function GetProdID($connect) {
  $query = "SELECT `prodID` FROM `products`;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_execute($stmt);
    $resultSet = mysqli_stmt_get_result($stmt);
    $result = array();
    while($row = mysqli_fetch_assoc($resultSet)) {
      $result[] = $row;
    }
    mysqli_stmt_close($stmt);
  }
  return $result;
}

function UpdateRating($connect, $rating, $prodID) {
  $query = "UPDATE `products` SET `rating` = ? WHERE `prodID` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "di", $rating, $prodID);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
  }
}

function GetUsername($connect, string $userName) {
  $query = "SELECT `userName` FROM `accounts` WHERE `userName` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "s", $userName);
    mysqli_stmt_execute($stmt);
    $result = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
  }
  return $result;
}

function GetMobileNumber($connect, string $mobileNumber) {
  $query = "SELECT `mobileNumber` FROM `accounts` WHERE `mobileNumber` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "s", $userName);
    mysqli_stmt_execute($stmt);
    $result = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
  }
  return $result;
}

function GetEmailSignup($connect, string $email) {
  $query = "SELECT `Email` FROM `accounts` WHERE `email` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
  }
  return $result;
}

function GetEmailLogin($connect, string $userName) {
  $query = "SELECT `email` FROM `accounts` WHERE `userName` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "s", $userName);
    mysqli_stmt_execute($stmt);
    $result = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
  }
  return $result;
}

function GetAccountID($connect, string $userName) {
  $query = "SELECT `accID` FROM `accounts` WHERE `userName` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "s", $userName);
    mysqli_stmt_execute($stmt);
    $result = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
  }
  return $result;
}

function GetPassword($connect, string $userName) {
  $query = "SELECT `password` FROM `accounts` WHERE `userName` = ?;";
  $stmt = mysqli_stmt_init($connect);
  if (!mysqli_stmt_prepare($stmt, $query)) {
    echo "Error: " . mysqli_error($connect);
  } else {
    mysqli_stmt_bind_param($stmt, "s", $userName);
    mysqli_stmt_execute($stmt);
    $result = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
    mysqli_stmt_close($stmt);
  }
  return $result;
}