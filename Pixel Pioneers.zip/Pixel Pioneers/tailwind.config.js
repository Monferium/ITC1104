/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}", "**/*.php", './index.php', './navbar.php', './footer.php', './contact_us.php', './sign_up.php', './product.php', './login.php', './landing_page.php', './cart.php', './about.php'],
  theme: {
    extend: {},
  },
  plugins: [],
}