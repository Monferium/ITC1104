<?php

$dbServername = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'pixel_pioneers'; 

// Connect

$connect = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

if(!$connect){
    die("Connection failed: " . mysqli_connect_error());
}
