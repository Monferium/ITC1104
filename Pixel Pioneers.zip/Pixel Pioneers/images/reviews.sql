-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2024 at 04:57 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pixel_pioneers`
--

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `revID` int(11) NOT NULL,
  `prodID` int(11) NOT NULL,
  `accID` int(11) NOT NULL,
  `rating` decimal(10,1) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `is_liked` tinyint(1) NOT NULL,
  `productImg` longblob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`revID`, `prodID`, `accID`, `rating`, `comments`, `is_liked`, `productImg`) VALUES
(1, 1, 22, 2.5, 'comments=01', 1, NULL),
(2, 1, 19, 4.5, 'comments=02', 0, NULL),
(3, 1, 21, 3.0, 'comments=03', 1, NULL),
(4, 2, 22, 1.5, 'comments=01', 0, NULL),
(5, 2, 19, 2.0, 'comments=02', 0, NULL),
(6, 2, 21, 4.0, 'comments=03', 1, NULL),
(7, 3, 22, 1.0, 'comments=01', 0, NULL),
(8, 3, 19, 0.5, 'comments=02', 0, NULL),
(9, 3, 21, 1.5, 'comments=03', 1, NULL),
(10, 4, 22, 4.5, 'comments=01', 1, NULL),
(11, 4, 19, 3.5, 'comments=02', 0, NULL),
(12, 4, 21, 2.5, 'comments=03', 0, NULL),
(13, 5, 22, 1.0, 'comments=01', 0, NULL),
(14, 5, 19, 5.0, 'comments=02', 1, NULL),
(15, 5, 21, 4.0, 'comments=03', 0, NULL),
(16, 6, 22, 3.0, 'comments=01', 0, NULL),
(17, 6, 19, 1.5, 'comments=02', 1, NULL),
(18, 6, 21, 2.0, 'comments=03', 1, NULL),
(19, 7, 22, 3.5, 'comments=01', 1, NULL),
(20, 7, 19, 1.5, 'comments=02', 0, NULL),
(21, 7, 21, 5.0, 'comments=03', 0, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`revID`),
  ADD KEY `product_Action` (`prodID`),
  ADD KEY `account_Action2` (`accID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `revID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `account_Action2` FOREIGN KEY (`accID`) REFERENCES `accounts` (`accID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `product_Action` FOREIGN KEY (`prodID`) REFERENCES `products` (`prodID`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
