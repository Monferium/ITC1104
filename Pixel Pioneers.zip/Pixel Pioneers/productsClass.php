<?php
require_once "sessionConfig.php";
require_once "dbConnector.php";
require_once "dbQueries.php";

class Product {
    public $prodID;
    public $name;
    public $price;
    public $image;
    public $rating;

    public function __construct($prodID, $name, $price, $image, $rating) {
        $this->prodID = $prodID;
        $this->name = $name;
        $this->price = $price;
        $this->image = $image;
        $this->rating = $rating;
    }

    public function displayProductsBox() {
        echo'<div>';
        echo'<div class="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">';
        echo'<div style = "object-fit: contain"><a href="#">';

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_buffer($finfo, $this->image);
        finfo_close($finfo);
        echo '<img class="p-8 rounded-t-lg" src="data:image/' . $mimeType . ';base64,' . base64_encode($this->image) . '" alt="Product Photo">';

        echo'</a></div>';
        echo'<div class="px-5 pb-5">';
        echo'<a href="#">';

        echo'<h5 class="text-xl font-semibold tracking-tight text-gray-900 dark:text-white">' . $this->name . '</h5>';
        echo'</a>';
        echo'<div class="flex items-center mt-2.5 mb-5">';
        echo'   <div class="flex items-center space-x-1 rtl:space-x-reverse">';
        // Display stars based on rating
        $starsToColor = round($this->rating);
        for ($i = 1; $i <= 5; $i++) {
            $starColorClass = $i <= $starsToColor ? 'yellow' : 'gray';
            echo '<svg class="w-4 h-4 text-' . $starColorClass . '-300" aria-hidden="true" fill="currentColor" viewBox="0 0 24 24"><path d="M12 .587l3.515 7.124 7.485 1.086-5.417 5.277 1.279 7.45L12 18.897l-6.862 3.627 1.279-7.45-5.417-5.277 7.485-1.086L12 .587z"/></svg>';
        }
        echo'</div>';

        echo '<span class="bg-blue-100 text-blue-800 text-xs font-semibold px-2.5 py-0.5 rounded dark:bg-blue-200 dark:text-blue-800 ms-3">' . $this->rating . '</span>';

        echo'</div>';
        echo'<div class="flex items-center justify-between">';

        echo '<span class="text-3xl font-bold text-gray-900 dark:text-white">₱' . $this->price . '</span>';
        if(isset($_SESSION['accID'])) {
            echo'            <a href="cartClass.php?add=' . $this->prodID . '" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Add to cart</a>';
        } else {
            echo'            <a href="login.php" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Add to cart</a>';
        }
        
        echo'</div>';
        echo'</div>';
        echo'</div>';
        echo'</div>';
    }
}
$resultProdID =  GetProdID($connect);
if($resultProdID) {
    foreach($resultProdID as $productID) {
        $ratings = GetRating($connect, $productID['prodID']);
        $totalRating = count($ratings);
        $sumRating = 0;
        foreach($ratings as $product) {
            $sumRating += $product['rating'];
        }
        $averageRating = $totalRating > 0 ? $sumRating / $totalRating : 0;
        UpdateRating($connect, $averageRating,  $productID['prodID']);
    }
}

$productsArray = array();
$resultProducts = GetProductsSeller($connect, 20);
if ($resultProducts) {
     foreach ($resultProducts as $row) {
        $product = new Product($row['prodID'], $row['name'], $row["price"], $row["image"], $row["rating"]);
        $productsArray[] = $product;
    }
} else {
    echo "No data found";
}
