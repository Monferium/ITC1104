<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Index</title>
<link href="src/output.css" rel="stylesheet">
</head>
<body>

<?php include 'navbar.php';?>



<?php echo '<div class="w-[1000px] px-4 mx-auto pt-12">
<div class="grid gap-4">
    <div>
        <img class="h-auto max-w-full rounded-lg" src="pics/all_products.png" alt="">
    </div>
    <div class="grid grid-cols-5 gap-4">
        <div>
            <img class="h-auto max-w-full rounded-lg" src="pics/1.png" alt="">
        </div>
        <div>
            <img class="h-auto max-w-full rounded-lg" src="pics/2.png" alt="">
        </div>
        <div>
            <img class="h-auto max-w-full rounded-lg" src="pics/3.png" alt="">
        </div>
        <div>
            <img class="h-auto max-w-full rounded-lg" src="pics/4.png" alt="">
        </div>
        <div>
            <img class="h-auto max-w-full rounded-lg" src="pics/5.png" alt="">
        </div>
    </div>
</div>
</div>'
;?>

<?php include 'footer.php';?>
</body>
</html>
