<?php require_once "sessionConfig.php"; 
      require_once "dbQueries.php";
      require_once "dbConnector.php";


function showIdentify($connect) {
  if(isset($_SESSION["accID"])) {
    $userData = GetPictureUsername($connect, $_SESSION["accID"]);
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_buffer($finfo, $userData['profilePic']);
    finfo_close($finfo);
echo '<div style="margin-left: 20px; border-radius: 5%;"><a href="dashboard.php" style="display: flex; width: 150px; height: 50px; margin: 10px; margin-left: 10px; align-items: center;">';
echo '<img src="data:image/' . $mimeType . ';base64,' . base64_encode($userData['profilePic']) . '" alt="Profile Picture of User" style="width: 100%; height: 100%; object-fit: cover; border-radius: 30%;">';
echo '<div style="display: flex; flex-direction: column; justify-content: space-between; padding: 10px;">';
echo '<p style="margin-bottom: 3px; font-weight: bolder;" class="py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Hello! ' . $userData['userName'] . '</p>';
echo '</div>';
echo '</a></div>';
  }
}

function showSL() {
  if(!isset($_SESSION["accID"])) {
    echo '<a href="login.php" class="inline-block text-white bg-blue-700 hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
          Login/Signup
          </a>';
  } else {
    echo '<a href="log_in_outLogic.php?logout" class="inline-block text-white bg-blue-700 hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
            Logout
          </a>';
  }
}
function showCart() {
  if(isset($_SESSION["accID"])) {
    echo '<li>
        <a href="cart.php" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Cart</a>
      </li>';
  }
}

?>
<?php
echo '<nav class="bg-white border-gray-200 dark:bg-gray-900 pt-12">
<div class="max-w-screen-xl flex flex-wrap items-center justify-between mx-auto p-4">
  <a href="https://flowbite.com/" class="flex items-center space-x-3 rtl:space-x-reverse">
      <img src="pics/site_logo.png" class="h-8" alt="Flowbite Logo" />
      <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">Hustle Every Dye</span>
  </a>
  <button data-collapse-toggle="navbar-default" type="button" class="inline-flex items-center p-2 w-10 h-10 justify-center text-sm text-gray-500 rounded-lg md:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600" aria-controls="navbar-default" aria-expanded="false">
      <span class="sr-only">Open main menu</span>
      <svg class="w-5 h-5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 17 14">
          <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 1h15M1 7h15M1 13h15"/>
      </svg>
  </button>';
 echo '<div class="hidden w-full md:block md:w-auto ml-auto p-8" id="navbar-default">
    <ul class="font-medium flex flex-col p-4 md:p-0 mt-4 border border-gray-100 rounded-lg bg-gray-50 md:flex-row md:space-x-8 rtl:space-x-reverse md:mt-0 md:border-0 md:bg-white dark:bg-gray-800 md:dark:bg-gray-900 dark:border-gray-700">
      <li>
        <a href="index.php" class="block py-2 px-3 text-white bg-blue-700 rounded md:bg-transparent md:text-blue-700 md:p-0 dark:text-white md:dark:text-blue-500" aria-current="page">Home</a>
      </li>
      <li>
        <a href="products.php" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Products</a>
      </li>';
  showCart();
      echo '<li>
        <a href="contact_us.php" class="block py-2 px-3 text-gray-900 rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0 md:hover:text-blue-700 md:p-0 dark:text-white md:dark:hover:text-blue-500 dark:hover:bg-gray-700 dark:hover:text-white md:dark:hover:bg-transparent">Contact</a>
      </li>
    </ul>
  </div>';
  showSL();
  echo '<br>';
  showIdentify($connect);
  echo '</div>
  </nav>';
  
  echo ' </div></nav>';
?>

<script>
  document.addEventListener("DOMContentLoaded", function() {
    const navbarToggle = document.querySelector("[data-collapse-toggle]");
    const navbarMenu = document.getElementById("navbar-default");

    navbarToggle.addEventListener("click", function() {
      navbarMenu.classList.toggle("hidden");
    });
  });
</script>